UPDATE plan SET
inn_id = ?,
plan_name = ?,
plan_content = ?
WHERE plan_id = plan.getPlanId();