DROP TABLE IF EXISTS inn;

CREATE TABLE inn(
inn_id SERIAL NOT NULL PRIMARY KEY,
inn_name VARCHAR(50) NOT NULL,
category_code INT NOT NULL,
inn_postalcode INT NOT NULL,
inn_address VARCHAR(200) NOT NULL,
checkin_time TIME NOT NULL,
checkout_time TIME NOT NULL
);

INSERT INTO inn(inn_name, category_code, inn_postalcode, inn_address, checkin_time, checkout_time)
values('ホテルグランドヒル市ヶ谷', 2, 1620845, '東京都新宿区市谷本村町４−１', '15:00', '10:00'),
('ホテルアトラス',0,2240032,'神奈川県横浜市都筑区茅ケ崎中央３６−６','0:00','23:59'),
('星野リゾート　軽井沢ホテルブレストンコート',1,3890195,'長野県軽井沢町星野','14:00','10:00'),
('大川荘',3,9695147,'福島県会津若松市大戸町大字芦牧 大字芦ノ牧下平９８４','16:00','11:00'),
('清流の宿　たむら',4,3791721,'群馬県利根郡みなかみ町藤原６２７３－２','15:00','10:00'),
('日光ワンモアタイム',5,3211421,'栃木県日光市所野１５４２ー２６５','15:00','10:00');