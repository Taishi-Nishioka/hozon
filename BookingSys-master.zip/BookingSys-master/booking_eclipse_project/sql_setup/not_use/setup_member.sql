create table member (member_id SERIAL NOT NULL PRIMARY KEY ,
name VARCHAR(50) NOT NULL ,
postalcode INT NOT NULL ,
address VARCHAR(200) NOT NULL ,
phone_number VARCHAR(20) NOT NULL ,
email VARCHAR(50) NOT NULL ,
birthday DATE ,
join_date DATE NOT NULL ,
leave_date DATE ,
password VARCHAR(20) NOT NULL ,
root_flag BOOLEAN
);