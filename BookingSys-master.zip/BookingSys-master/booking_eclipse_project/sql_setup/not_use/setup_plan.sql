DROP TABLE IF EXISTS plan;

CREATE TABLE plan(
plan_id SERIAL NOT NULL PRIMARY KEY,
inn_id INTEGER NOT NULL,
plan_name VARCHAR(50) NOT NULL,
plan_contents TEXT NOT NULL,
price INTEGER NOT NULL,
room_quantity INTEGER NOT NULL,
delete_date DATE,
remark TEXT
)