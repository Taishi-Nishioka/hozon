CREATE TABLE category(
category_code INTEGER NOT NULL PRIMARY KEY,
category_name VARCHAR(20) NOT NULL);

INSERT INTO category values
(0, 'シティホテル'),
(1, 'リゾートホテル'),
(2, 'ビジネスホテル'),
(3, '旅館'),
(4, '民宿'),
(5, 'ペンション');