CREATE TABLE reservation(
 reservation_id SERIAL NOT NULL PRIMARY KEY,
 member_id INT NOT NULL ,
 plan_id INT NOT NULL ,
 reserved_time TIME NOT NULL ,
 checkin_date DATE NOT NULL ,
 checkout_date DATE NOT NULL ,
 room_number INT NOT NULL ,
 cancel BOOLEAN NOT NULL ,
 remark VARCHAR
)

