CREATE TABLE review(
review_id SERIAL,
plan_id INTEGER NOT NULL,
post_datetime TIMESTAMP,
review_title VARCHAR(50) NOT NULL,
review_content VARCHAR(2000) NOT NULL,
rating INTEGER NOT NULL, PRIMARY KEY(review_id, plan_id));
