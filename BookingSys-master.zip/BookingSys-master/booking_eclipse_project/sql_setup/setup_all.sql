DROP TABLE IF EXISTS category,member,reservation,plan,inn;

CREATE TABLE category(
category_code INTEGER NOT NULL PRIMARY KEY,
category_name VARCHAR(20) NOT NULL);

create table member (
member_id SERIAL NOT NULL PRIMARY KEY ,
name VARCHAR(50) NOT NULL ,
postalcode INT NOT NULL ,
address VARCHAR(200) NOT NULL ,
phone_number VARCHAR(20) NOT NULL ,
email VARCHAR(50) NOT NULL UNIQUE,
birthday DATE ,
join_date DATE NOT NULL ,
leave_date DATE,
password VARCHAR(20) NOT NULL ,
admin BOOLEAN NOT NULL
);

CREATE TABLE inn(
inn_id SERIAL NOT NULL PRIMARY KEY,
inn_name VARCHAR(50) NOT NULL,
category_code INT NOT NULL,
inn_postalcode INT NOT NULL,
inn_address VARCHAR(200) NOT NULL,
checkin_time TIME NOT NULL,
checkout_time TIME NOT NULL
);

CREATE TABLE plan(
plan_id SERIAL NOT NULL PRIMARY KEY,
inn_id INTEGER NOT NULL,
plan_name VARCHAR(100) NOT NULL,
plan_content VARCHAR NOT NULL,
price INTEGER NOT NULL,
room_quantity INTEGER NOT NULL,
delete_date DATE,
plan_remark VARCHAR
);

CREATE TABLE reservation(
 reservation_id SERIAL NOT NULL PRIMARY KEY,
 member_id INT NOT NULL ,
 plan_id INT NOT NULL ,
 reserved_time TIMESTAMP NOT NULL ,
 checkin_date DATE NOT NULL ,
 checkout_date DATE NOT NULL ,
 room_quantity INT NOT NULL ,
 cancel BOOLEAN NOT NULL ,
 remark VARCHAR
);

INSERT INTO category values
(0, 'シティホテル'),
(1, 'リゾートホテル'),
(2, 'ビジネスホテル'),
(3, '旅館'),
(4, '民宿'),
(5, 'ペンション');

INSERT INTO member (name,postalcode,address,phone_number,email,join_date,password,admin) VALUES('田中太郎','1234567','栃木県','000-0000-0000','hoge0@hoge','2021-5-19','a.1',TRUE) ,('佐藤一郎','2345678','神奈川県','000-0000-0001','hoge1@hoge','2002-4-5','a.2',FALSE) ,('藤原加奈子','3456789','東京都','000-0000-0002','hoge2@hoge','2002-4-6','a.3',FALSE) ,('山本新','4567900','埼玉県','000-0000-0003','hoge3@hoge','2002-4-7','a.4',FALSE) ,('加藤雄一','5679011','大阪府','000-0000-0004','hoge4@hoge','2002-4-8','a.5',FALSE) ,('伊東光子','6790122','千葉県','000-0000-0005','hoge5@hoge','2002-4-9','a.6',FALSE) ,('小林義光','7901233','宮城県','000-0000-0006','hoge6@hoge','2002-4-10','a.7',FALSE) ,('佐々木一郎','9012344','北海道','000-0000-0007','hoge7@hoge','2002-4-11','a.8',FALSE) ,('松本大','10123455','沖縄県','000-0000-0008','hoge8@hoge','2002-4-12','a.9',FALSE) ,('清水恵子','11234566','京都府','000-0000-0009','hoge9@hoge','2002-4-13','a.10',FALSE) ,('山崎恵','12345677','大阪府','000-0000-0010','hoge10@hoge','2002-4-14','a.11',FALSE) ,('安倍秋','13456788','東京都','000-0000-0011','hoge11@hoge','2002-4-15','a.12',FALSE) ,('原巧','14567899','群馬県','000-0000-0012','hoge12@hoge','2002-4-16','a.13',FALSE) ,('石川友則','15679010','栃木県','000-0000-0013','hoge13@hoge','2002-4-17','a.14',FALSE) ,('長谷川優','16790121','宮崎県','000-0000-0014','hoge14@hoge','2002-4-18','a.15',FALSE) ,('小早川豊','17901232','熊本県','000-0000-0015','hoge15@hoge','2002-4-19','a.16',FALSE) ,('武田浩一郎','19012343','三重県','000-0000-0016','hoge16@hoge','2002-4-20','a.17',FALSE) ,('上野駆','20123454','愛知県','000-0000-0017','hoge17@hoge','2002-4-21','a.18',FALSE) ,('中西弘明','21234565','静岡県','000-0000-0018','hoge18@hoge','2002-4-22','a.19',FALSE) ,('小泉一樹','22345676','山梨県','000-0000-0019','hoge19@hoge','2002-4-23','a.20',FALSE) ,('河野太郎','23456787','福島県','000-0000-0020','hoge20@hoge','2002-4-24','a.21',FALSE);
INSERT INTO plan (inn_id,plan_name,plan_content,price,room_quantity) VALUES(12,'プラン1','これはプラン1の説明文です！！！！！',4000,10),(1,'プラン2','これはプラン2の説明文です！！！！！',5000,5),(5,'プラン3','これはプラン3の説明文です！！！！！',6000,5),(10,'プラン4','これはプラン4の説明文です！！！！！',7000,5),(8,'プラン5','これはプラン5の説明文です！！！！！',8000,5),(10,'プラン6','これはプラン6の説明文です！！！！！',9000,5),(4,'プラン7','これはプラン7の説明文です！！！！！',10000,5),(10,'プラン8','これはプラン8の説明文です！！！！！',11000,5),(7,'プラン9','これはプラン9の説明文です！！！！！',12000,5),(12,'プラン10','これはプラン10の説明文です！！！！！',13000,5),(7,'プラン11','これはプラン11の説明文です！！！！！',14000,5),(11,'プラン12','これはプラン12の説明文です！！！！！',15000,5),(2,'プラン13','これはプラン13の説明文です！！！！！',16000,5),(5,'プラン14','これはプラン14の説明文です！！！！！',17000,5),(13,'プラン15','これはプラン15の説明文です！！！！！',18000,5),(2,'プラン16','これはプラン16の説明文です！！！！！',19000,5),(11,'プラン17','これはプラン17の説明文です！！！！！',20000,5),(11,'プラン18','これはプラン18の説明文です！！！！！',21000,5),(6,'プラン19','これはプラン19の説明文です！！！！！',22000,5),(4,'プラン20','これはプラン20の説明文です！！！！！',23000,5);
INSERT INTO inn (inn_name,category_code,inn_postalcode,inn_address,checkin_time,checkout_time) VALUES('小川荘',3,1,'東京都','15:00','10:00') ,('ホテルグランヴィア',2,2,'埼玉県','15:00','10:00') ,('吉野リゾート',1,3,'大阪府','15:00','10:00') ,('アーバンリゾート',1,4,'千葉県','15:00','10:00') ,('月見亭',3,5,'宮城県','15:00','10:00') ,('西横イン',0,6,'北海道','15:00','10:00') ,('ウェルキャンプ',5,7,'沖縄県','15:00','10:00') ,('ホテル大洗',1,8,'京都府','15:00','10:00') ,('貝殻荘',4,9,'大阪府','15:00','10:00') ,('チェルシーホテル',0,10,'東京都','15:00','10:00') ,('AgeHa',1,11,'群馬県','15:00','10:00') ,('サブテラニアン',0,12,'栃木県','15:00','10:00') ,('桜の丘',5,13,'宮崎県','15:00','10:00');

