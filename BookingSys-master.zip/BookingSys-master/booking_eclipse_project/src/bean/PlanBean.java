package bean;

import java.io.Serializable;

public class PlanBean implements Serializable{
	Integer planId;
	String planName;
	Integer innId;
	String innName;
	Integer categoryCode;
	String categoryName;
	String planContent;
	Integer price;
	java.sql.Date deleteDate;
	Integer roomQuantity;
	String remark;

	public PlanBean() {
		super();
		planId = null;
		planName = null;
		innId = null;
		innName = null;
		categoryCode = null;
		categoryName = null;
		planContent = null;
		price = null;
		roomQuantity = null;
	}

	public PlanBean(int planId, String planName, int innId, String innName, int categoryCode, String categoryName,
			String planContent, int price, int rooms) {
		super();
		this.planId = planId;
		this.planName = planName;
		this.innId = innId;
		this.innName = innName;
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
		this.planContent = planContent;
		this.price = price;
		this.roomQuantity = rooms;
	}



	@Override
	public String toString() {
		return "PlanBean [planId=" + planId + ", planName=" + planName + ", innId=" + innId + ", innName=" + innName
				+ ", categoryCode=" + categoryCode + ", categoryName=" + categoryName + ", planContent=" + planContent
				+ ", price=" + price + ", deleteDate=" + deleteDate + ", roomQuantity=" + roomQuantity + ", remark="
				+ remark + "]";
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Integer getInnId() {
		return innId;
	}

	public void setInnId(Integer innId) {
		this.innId = innId;
	}

	public String getInnName() {
		return innName;
	}

	public void setInnName(String innName) {
		this.innName = innName;
	}

	public Integer getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(Integer catCode) {
		this.categoryCode = catCode;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String catName) {
		this.categoryName = catName;
	}

	public String getPlanContent() {
		return planContent;
	}

	public void setPlanContent(String planContent) {
		this.planContent = planContent;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getRoomQuantity() {
		return roomQuantity;
	}

	public void setRoomQuantity(Integer rooms) {
		this.roomQuantity = rooms;
	}

	public java.sql.Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(java.sql.Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
