package bean;

import java.io.Serializable;

public class SearchPlanBean extends PlanBean implements Serializable{
	Integer lowPrice;
	Integer highPrice;
	String innAddress;
	boolean admin;
	public Integer getLowPrice() {
		return lowPrice;
	}
	public void setLowPrice(Integer lowPrice) {
		this.lowPrice = lowPrice;
	}
	public Integer getHighPrice() {
		return highPrice;
	}
	public void setHighPrice(Integer highPrice) {
		this.highPrice = highPrice;
	}
	public String getInnAddress() {
		return innAddress;
	}
	public void setInnAddress(String innAddress) {
		this.innAddress = innAddress;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public SearchPlanBean() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public SearchPlanBean(int planId, String planName, int innId, String innName, int categoryCode, String categoryName,
			String planContent, int price, int rooms, Integer lowPrice, Integer highPrice, String innAddress,
			boolean admin) {
		super(planId, planName, innId, innName, categoryCode, categoryName, planContent, price, rooms);
		this.lowPrice = lowPrice;
		this.highPrice = highPrice;
		this.innAddress = innAddress;
		this.admin = admin;
	}

}
