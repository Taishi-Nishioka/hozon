package bean;

import java.sql.Date;
import java.sql.Timestamp;

public class ReservationDetailBean extends ReservationBean{
	String planName;
	int price;
	String innName;
	int totalPrice;
	public int getTotalPrice() {
		return price * getRoomQuantity();
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) { // かならずsetRoomQuantityより先に行う
		this.price = price;
	}
	public String getInnName() {
		return innName;
	}
	public void setInnName(String innName) {
		this.innName = innName;
	}
	public ReservationDetailBean(String planName, int price, String innName) {
		super();
		this.planName = planName;
		this.price = price;
		this.innName = innName;
	}
	public ReservationDetailBean() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}
	public ReservationDetailBean(int memberId, int planId, int reservationId, Date checkinDate, Date checkoutDate,
			int roomQuantity, Timestamp reservedTime, boolean cancel) {
		super(memberId, planId, reservationId, checkinDate, checkoutDate, roomQuantity, reservedTime, cancel);
		// TODO 自動生成されたコンストラクター・スタブ
	}
	

}
