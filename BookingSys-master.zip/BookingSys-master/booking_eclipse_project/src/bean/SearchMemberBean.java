package bean;

import java.io.Serializable;
import java.util.Date;

public class SearchMemberBean implements Serializable{
	private Integer memberID;
	private String memberName;
	private Date birthday;
	private String phoneNum;
	private String email;
	private boolean admin;

	public SearchMemberBean() {
		super();
		memberID = null;
		memberName = null;
		setBirthday(null);
		phoneNum = null;
		email = null;
		admin = false;
	}


	public SearchMemberBean(Integer memberID, String menberName, Date birthday,
			String phoneNum, String email, boolean admin) {
		super();
		this.memberID = memberID;
		this.memberName = menberName;
		this.setBirthday(birthday);
		this.phoneNum = phoneNum;
		this.email = email;
		this.admin = admin;
	}

	public Integer getMemberID() {
		return memberID;
	}

	public void setMemberID(Integer memberID) {
		this.memberID = memberID;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}


	public Date getBirthday() {
		return birthday;
	}


	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}



}
