package bean;

import java.sql.Date;
import java.sql.Timestamp;

public class ReservationBean {




	@Override
	public String toString() {
		return "ReservationBean [member_id=" + memberId + ", plan_id=" + planId + ", reservation_id=" + reservationId
				+ ", checkin_date=" + checkinDate + ", checkout_date=" + checkoutDate + ", room_quantity="
				+ roomQuantity + ", reserved_time=" + reservedTime + ", cancel=" + cancel + "]";
	}
	private int memberId;
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}


	private int planId;
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}


	private int reservationId;
	public int getReservationId() {
		return reservationId;
	}
	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}


	private Date checkinDate;
	public Date getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(Date checkinDate) {
		this.checkinDate = checkinDate;
	}


	private Date checkoutDate;
	public Date getCheckoutDate() {
		return checkoutDate;
	}
	public void setCheckoutDate(Date checkoutDate) {
		this.checkoutDate = checkoutDate;
	}


	private int roomQuantity;
	public int getRoomQuantity() {
		return roomQuantity;
	}
	public void setRoomQuantity(int roomQuantity) {
		this.roomQuantity = roomQuantity;
	}


	private Timestamp reservedTime;
	public Timestamp getReservedTime() {
		return reservedTime;
	}
	public void setReservedTime(Timestamp reservedTime) {
		this.reservedTime = reservedTime;
	}


	private boolean cancel;

	public boolean isCancel() {
		return cancel;
	}
	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}






	public ReservationBean() {

	}
	public ReservationBean(int memberId, int planId, int reservationId, Date checkinDate, Date checkoutDate,
			int roomQuantity, Timestamp reservedTime, boolean cancel) {
		super();
		this.memberId = memberId;
		this.planId = planId;
		this.reservationId = reservationId;
		this.checkinDate = checkinDate;
		this.checkoutDate = checkoutDate;
		this.roomQuantity = roomQuantity;
		this.reservedTime = reservedTime;
		this.cancel = cancel;
	}





}
