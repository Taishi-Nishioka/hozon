package bean;

import java.io.Serializable;
import java.sql.Date;

public class MemberBean implements Serializable{
	private Integer memberID;
	private String memberName;
	private Integer memberPostalCode;
	private String memberAddress;
	private String phoneNum;
	private String email;
	private Date  birthday;
	private Date joinDate;
	private Date leaveDate;
	private String password;
	private boolean admin;

	public MemberBean(Integer memberID, String memberName, Integer memberPostalCode, String menberAddress,
			String phoneNum, String email, Date birthday, Date joinDate, Date leaveDate, String password,
			boolean admin) {
		super();
		this.memberID = memberID;
		this.memberName = memberName;
		this.memberPostalCode = memberPostalCode;
		this.memberAddress = menberAddress;
		this.phoneNum = phoneNum;
		this.email = email;
		this.birthday = birthday;
		this.joinDate = joinDate;
		this.leaveDate = leaveDate;
		this.password = password;
		this.admin = admin;
	}

	public MemberBean() {
		super();
		memberID = null;
		memberName = null;
		memberPostalCode = null;
		memberAddress = null;
		phoneNum = null;
		email = null;
		birthday = null;
		joinDate = null;
		leaveDate = null;
		password = null;
		admin = false;
	}

	public Integer getMemberID() {
		return memberID;
	}

	public void setMemberID(Integer memberID) {
		this.memberID = memberID;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Integer getMemberPostalCode() {
		return memberPostalCode;
	}

	public void setMemberPostalCode(Integer memberPostalCode) {
		this.memberPostalCode = memberPostalCode;
	}

	public String getMemberAddress() {
		return memberAddress;
	}

	public void setMemberAddress(String memberAddress) {
		this.memberAddress = memberAddress;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	@Override
	public String toString() {
		return "MemberBean [memberID=" + memberID + ", memberName=" + memberName + ", memberPostalCode="
				+ memberPostalCode + ", memberAddress=" + memberAddress + ", phoneNum=" + phoneNum + ", email=" + email
				+ ", birthday=" + birthday + ", joinDate=" + joinDate + ", leaveDate=" + leaveDate + ", password="
				+ password + ", admin=" + admin + "]";
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Date getJoinDate() {
		return joinDate;
	}

	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}

	public Date getLeaveDate() {
		return leaveDate;
	}

	public void setLeaveDate(Date leaveDate) {
		this.leaveDate = leaveDate;
	}

}
