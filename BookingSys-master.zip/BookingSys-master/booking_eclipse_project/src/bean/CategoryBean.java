package bean;

import java.io.Serializable;

public class CategoryBean implements Serializable{
	int categoryCode;
	String categoryName;
	@Override
	public String toString() {
		return "CategoryBean [categoryCode=" + categoryCode + ", categoryName=" + categoryName + "]";
	}
	public int getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(int categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public CategoryBean(int categoryCode, String categoryName) {
		super();
		this.categoryCode = categoryCode;
		this.categoryName = categoryName;
	}
	public CategoryBean() {
		super();
		// TODO 自動生成されたコンストラクター・スタブ
	}

}
