package bean;

import java.io.Serializable;
import java.sql.Time;

public class InnBean implements Serializable {
	private int innId;
	private String innName;
	private int categoryCode;
	private Integer innPostalCode;
	private String innAddress;
	private Time checkinTime;
	private Time checkoutTime;

	public InnBean() {
	}

	public InnBean(String innName, int categoryCode, Integer innPostalCode, String innAddress, Time checkinTime,
			Time checkoutTime) {
		this.innName = innName;
		this.categoryCode = categoryCode;
		this.innPostalCode = innPostalCode;
		this.innAddress = innAddress;
		this.checkinTime = checkinTime;
		this.checkoutTime = checkoutTime;
	}

	public int getInnId() {
		return innId;
	}

	public void setInnId(int innId) {
		this.innId = innId;
	}

	public String getInnName() {
		return innName;
	}

	public void setInnName(String innName) {
		this.innName = innName;
	}

	public int getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(int categoryCode) {
		this.categoryCode = categoryCode;
	}

	public Integer getInnPostalCode() {
		return innPostalCode;
	}

	public void setInnPostalCode(Integer innPostalCode) {
		this.innPostalCode = innPostalCode;
	}

	public String getInnAddress() {
		return innAddress;
	}

	public void setInnAddress(String innAddress) {
		this.innAddress = innAddress;
	}

	public Time getCheckinTime() {
		return checkinTime;
	}

	public void setCheckinTime(Time checkinTime) {
		this.checkinTime = checkinTime;
	}

	public Time getCheckoutTime() {
		return checkoutTime;
	}

	public void setCheckoutTime(Time checkoutTime) {
		this.checkoutTime = checkoutTime;
	}

	@Override
	public String toString() {
		return "InnBean [innId=" + innId + ", innName=" + innName + ", categoryCode=" + categoryCode
				+ ", innPostalCode=" + innPostalCode + ", innAddress=" + innAddress + ", checkinTime=" + checkinTime
				+ ", checkoutTime=" + checkoutTime + "]";
	}

}
