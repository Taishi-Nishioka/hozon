package servlet;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.MemberBean;
import dao.MemberDao;
import dao.ReservationDao;
import tools.ServletTools;

/**
 * Servlet implementation class PlanListServlet
 */
@WebServlet("/MemberListServlet")
public class MemberListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MemberListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String action = request.getParameter("action");
		System.out.println("Servlet action:" + action);
		HttpSession session = request.getSession(false); //会員検索
		//ログインしている時に許可する動作
		if (session.getAttribute("loginMemberId") != null) {
			int memberId = (int) session.getAttribute("loginMemberId");
			if (ServletTools.equalString(action, "searchMember")) {
				//			Forward.viewPage("/plan/plans.jsp", searchList(request, 10), response);
				HttpServletRequest originalRequest = searchMember(request);
				RequestDispatcher rd = originalRequest.getRequestDispatcher("/member.jsp");
				rd.forward(originalRequest, response);
			} else if (ServletTools.equalString(action, "edit")) {
				try {
					request.setAttribute("memberdata", MemberDao.searchMemberById(Integer.parseInt(request.getParameter("memberID"))));
					ServletTools.viewPage("memberInfoUpdate.jsp", request, response);
				}catch(NumberFormatException e) {
					request.setAttribute("message", "予期しないエラーが発生しました");
					ServletTools.viewPage("/message.jsp", request, response);
				}
			} else if (ServletTools.equalString(action, "update")) {
				//会員情報の更新

				updateInfo(request);
				request.setAttribute("message", "更新しました");
				RequestDispatcher rd = request.getRequestDispatcher("/message.jsp");
				rd.forward(request, response);
			} else if (ServletTools.equalString(action, "check")) {
				//ログイン会員IDで検索

				int userId = (Integer) session.getAttribute("loginMemberId");
				MemberBean member = MemberDao.searchMemberById(userId);
				request.setAttribute("memberdata", member);
				//いつもの
				RequestDispatcher rd = request.getRequestDispatcher("/memberInfoUpdate.jsp");
				rd.forward(request, response);
			} else if (ServletTools.equalString(action, "checkWithdraw")) {
				//退会確認
				ServletTools.viewPage("/member/checkWithdraw.jsp", request, response);
			} else if (ServletTools.equalString(action, "withdraw")) {
				//退会
				MemberDao.withdraw(memberId);
				ReservationDao.withdraw(memberId);
				session.invalidate();
				request.setAttribute("message", "正常に退会が完了しました");
				ServletTools.viewPage("message.jsp", request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.forward(request, response);
			}
		} else if (ServletTools.equalString(action, "verified")) {

			//サインアップ
			request.setAttribute("message", "登録が完了しました!");
			HttpServletRequest originalRequest = signUp(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("/message.jsp");
			rd.forward(originalRequest, response);

		} else {
			//ログインしていない時だけ許可する動作
			request.setAttribute("message", "ログインしてください");
			ServletTools.viewPage("login", request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		doGet(request, response);
	}

	private HttpServletRequest searchMember(HttpServletRequest request) {
		System.out.println("searching member....");

		/*SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd"); //日付のFormatを指定
		sdf.setLenient(false); //日付の妥当性check
		LocalDate lcdate = new LocalDate();
		*/

		MemberBean search = new MemberBean();

		//以下検索項目

		search.setMemberName(request.getParameter("memberName"));
		try {
			search.setMemberID(Integer.parseInt(request.getParameter("memberId")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			search.setMemberPostalCode(Integer.parseInt(request.getParameter("memberPostalCode")));
		} catch (NumberFormatException e) {
		}
		search.setMemberAddress(request.getParameter("memberAddress"));
		search.setPhoneNum(request.getParameter("phoneNum"));
		search.setEmail(request.getParameter("email"));
		try {
			search.setBirthday(java.sql.Date.valueOf(birthToDate(request)));
			search.setJoinDate(java.sql.Date.valueOf(LocalDate.parse(request.getParameter("joinDate"))));
			search.setLeaveDate(java.sql.Date.valueOf(LocalDate.parse(request.getParameter("leaveDate"))));
		} catch (Exception e) {
		}

		//search.setAdmin(true);//メンバーテーブルから管理者かどうか判断する。
		MemberDao memberDao = new MemberDao();
		List<MemberBean> memberBean = memberDao.searchMember(search); //searchの内容をDaoに渡す
		System.out.println(search);
		request.setAttribute("memberList", memberBean);
		/*		int page = 1;
				try {
					page = Integer.parseInt(request.getParameter("page"));
				} catch (NumberFormatException e) {
					e.printStackTrace();
				}
				memberList = MemberDao.searchMember(search, page - 1, step);
		//		System.out.println("Current Page : " + page);
				request.setAttribute("currentPage", page);
		//		System.out.println("maxPage : " + ((planDao.searchPlanCount(search) + step - 1) / step));
				request.setAttribute("maxPage", ((planDao.searchPlanCount(search) + step - 1) / step));
				request.setAttribute("memberList", planList);
		*/
		return request;
	}

	private HttpServletRequest updateInfo(HttpServletRequest request) {
		System.out.println("updated member");
		MemberBean update = new MemberBean();

		//以下更新項目
		update.setMemberID(Integer.parseInt(request.getParameter("memberId")));
		update.setMemberName(request.getParameter("memberName"));
		update.setMemberPostalCode(Integer.parseInt(request.getParameter("memberPostalCode")));
		update.setMemberAddress(request.getParameter("memberAddress"));

		update.setPhoneNum(request.getParameter("phoneNum"));
		update.setEmail(request.getParameter("email"));

		try {
			update.setBirthday(java.sql.Date.valueOf(birthToDate(request)));
		} catch (Exception e) {
			e.printStackTrace();
		}

		update.setPassword(request.getParameter("password"));

		MemberDao memberDao = new MemberDao();//つけたし
		memberDao.updateMember(update);
		HttpSession session = request.getSession(false);
		session.setAttribute("loginMemberName", MemberDao.searchMemberById(update.getMemberID()).getMemberName());
		/*List<MemberBean> memberBean = memberDao.searchMember(update); //updateの内容をDaoに渡す
		System.out.println(update);
		request.setAttribute("memberList", memberBean);*/
		return request;
	}

	private HttpServletRequest signUp(HttpServletRequest request) {
		System.out.println("sign up");
		MemberBean signup = new MemberBean();

		//登録内容
		signup.setMemberName(request.getParameter("memberName"));
		signup.setMemberPostalCode(Integer.parseInt(request.getParameter("memberPostalCode")));
		signup.setMemberAddress(request.getParameter("memberAddress"));
		signup.setPhoneNum(request.getParameter("phoneNum"));
		signup.setEmail(request.getParameter("email"));

		try {
			signup.setBirthday(java.sql.Date.valueOf(birthToDate(request)));
		} catch (Exception e) {
			e.printStackTrace();
		}

		signup.setPassword(request.getParameter("password"));
		signup.setAdmin(false);

		MemberDao memberDao = new MemberDao();
		signup = memberDao.signUp(signup); //searchの内容をDaoに渡す
		HttpSession session = request.getSession();
		session.setAttribute("loginMemberName", signup.getMemberName());
		session.setAttribute("loginMemberId", signup.getMemberID());
		session.setAttribute("isAdmin", false);
		request.setAttribute("memberList", signup);

		return request;
	}

	/*	private HttpServletRequest searchMemberByID(HttpServletRequest request) {
			MemberDao memberDao = new MemberDao();
			int memberID = Integer.parseInt(request.getParameter("memberID"));

			MemberBean MemberData = memberDao.searchMemberById(memberID);

		private HttpServletRequest searchID(HttpServletRequest request) {
			MemberDao memberDao = new MemberDao();
			int memberID = Integer.parseInt(request.getParameter("memberID"));

			MemberBean MemberData = MemberDao.searchMemberByID(memberID);

			request.setAttribute("menmberData", MemberData);
			return request;
		}
	*/

	private LocalDate birthToDate(HttpServletRequest request) throws Exception {
		int date = Integer.parseInt(request.getParameter("birthDate"));
		int month = Integer.parseInt(request.getParameter("birthMonth"));
		int year = Integer.parseInt(request.getParameter("birthYear"));
		return LocalDate.of(year, month, date);
	}
}
