package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.CategoryBean;
import bean.MemberBean;
import dao.CategoryDao;
import dao.MemberDao;
import tools.ServletTools;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		if(ServletTools.equalString(action, "logout")) {
			request.getSession().invalidate();
			request.setAttribute("message", "ログアウトしました" );
			ServletTools.viewPage("message.jsp", request, response);
		}else {
			ServletTools.viewPage("login.jsp", request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String action = request.getParameter("action");
		if (ServletTools.equalString(action, "login")) {
			HttpSession session = request.getSession();
			MemberDao mDao = new MemberDao();
			MemberBean member = mDao.login(request.getParameter("email"), request.getParameter("password"));
			if ( member != null) {
				session.setAttribute("loginMemberName", member.getMemberName());
				session.setAttribute("loginMemberId", member.getMemberID());
				session.setAttribute("isAdmin", member.isAdmin());
				System.out.println(member.isAdmin());
				if(member.isAdmin()) {
					ServletTools.viewPage("adminMenu.jsp", request, response);
				}else {
					ServletTools.viewPage("mypage.jsp", request, response);
				}
			}else{
				request.setAttribute("message","ログインできませんでした");
				ServletTools.viewPage("login.jsp", request, response);
			}
		}else if(ServletTools.equalString(action, "logout")) {
			request.getSession().invalidate();
			request.setAttribute("message", "ログアウトしました" );
			ServletTools.viewPage("message.jsp", request, response);
		}else {
			ServletTools.viewPage("login.jsp", request, response);
		}
	}

	@Override
	public void init() throws ServletException {
		System.out.println("アプリケーションスコープへ");
		List<CategoryBean> categories = CategoryDao.findAllCategory();
		getServletContext().setAttribute("categories", categories);
	}

}
