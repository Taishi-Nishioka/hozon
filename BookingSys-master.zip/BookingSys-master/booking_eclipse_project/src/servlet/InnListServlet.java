package servlet;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.InnBean;
import dao.InnDao;
import tools.ServletTools;

/**
 * Servlet implementation class InnListServlet
 */
@WebServlet("/InnListServlet")
public class InnListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InnListServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		String action = request.getParameter("action");
		HttpSession session = request.getSession(false);
		if (session == null || session.getAttribute("isAdmin") == null ||!( (boolean) session.getAttribute("isAdmin"))) {
			request.setAttribute("message", "予期しないエラーが発生しました");
			ServletTools.viewPage("message.jsp", request, response);
		} else if (action == null || action.length() == 0) {
			ServletTools.viewPage("mypage.jsp", request, response);
		} else if (ServletTools.equalString(action, "searchList")) {
			ServletTools.viewPage("inns.jsp", searchList(request, 7), response);
			/*
			HttpServletRequest originalRequest = searchList(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("inns.jsp");
			rd.forward(originalRequest, response);*/
		} else if (action.equals("check")) {
			HttpServletRequest originalRequest = searchInn(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("changeInn.jsp");
			rd.forward(originalRequest, response);
		} else if (action.equals("change")) {
			request.setAttribute("message", "変更が完了しました");
			HttpServletRequest originalRequest = upInn(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("message.jsp");
			rd.forward(originalRequest, response);
		} else if (action.equals("add")) {
			request.setAttribute("message", "登録が完了しました");
			HttpServletRequest originalRequest = addInn(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("message.jsp");
			rd.forward(originalRequest, response);
		} else if (action.equals("delete")) {
			HttpServletRequest originalRequest = deleteInn(request);
			RequestDispatcher rd = originalRequest.getRequestDispatcher("deletedInnCp.jsp");
			rd.forward(originalRequest, response);
		} else if (action.equals("checkdelete")) {
			InnDao dao = new InnDao();
			try {
				request.setAttribute("innData", dao.searchInnById(Integer.parseInt(request.getParameter("innId"))));
				ServletTools.viewPage("checkDeleteInn.jsp", request, response);
			} catch (NumberFormatException e) {
				e.printStackTrace();
				ServletTools.viewPage("inns.jsp", searchList(request, 7), response);
			}
		} else if (ServletTools.equalString(action, "deleteVerified")) {
			InnDao dao = new InnDao();
			if (dao.deleteInn(Integer.parseInt(request.getParameter("innId"))) == 1) {
				request.setAttribute("message", "削除しました");
				HttpServletRequest originalRequest = searchInn(request);
				RequestDispatcher rd = originalRequest.getRequestDispatcher("message.jsp");
				rd.forward(originalRequest, response);
			} else {
				request.setAttribute("message", "予期しないエラーが発生しました。最初からやり直してください");
				ServletTools.viewPage("/message.jsp", request, response);
			}
		} else {

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	//一覧表示
	private HttpServletRequest searchList(HttpServletRequest request, int step) {
		System.out.println("searching inn....");
		InnBean search = new InnBean();
		search.setInnName(request.getParameter("innName"));

		try {
			search.setInnPostalCode(Integer.parseInt(request.getParameter("innPostalCode")));
		} catch (Exception e) {
			e.printStackTrace();
		}

		search.setInnAddress(request.getParameter("innAddress"));
		try {
			search.setCategoryCode(Integer.parseInt(request.getParameter("categoryCode")));
		} catch (Exception e) {
			e.printStackTrace();
		}

		InnDao innDao = new InnDao();
		List<InnBean> innList = new ArrayList<InnBean>();

		//		System.out.println(search);
		int page = 1;
		try {
			page = Integer.parseInt(request.getParameter("page"));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		innList = innDao.searchInn(search, page - 1, step);
		request.setAttribute("currentPage", page);
		/*	//		System.out.println("maxPage : " + ((planDao.searchPlanCount(search) + step - 1) / step));
					*/
		request.setAttribute("maxPage", ((innDao.searchInnCount(search) + step - 1) / step));
		for (InnBean inn : innList) {
			System.out.println(inn);
		}
		request.setAttribute("innList", innList);
		return request;
	}

	//IDで検索
	private HttpServletRequest searchInn(HttpServletRequest request) {
		InnDao innDao = new InnDao();
		int innId = Integer.parseInt(request.getParameter("innId"));

		InnBean innData = innDao.searchInnById(innId);

		request.setAttribute("innData", innData);
		return request;
	}

	//UPDATEを実行
	private HttpServletRequest upInn(HttpServletRequest request) {
		InnDao innDao = new InnDao();
		InnBean upInn = new InnBean();
		try {
			upInn.setInnId(Integer.parseInt(request.getParameter("InnId")));
			upInn.setInnName(request.getParameter("InnName"));
			upInn.setCategoryCode(Integer.parseInt(request.getParameter("CategoryCode")));
			upInn.setInnPostalCode((Integer.parseInt(request.getParameter("InnPostalCode"))));
			upInn.setInnAddress(request.getParameter("InnAddress"));
			upInn.setCheckinTime(Time.valueOf(request.getParameter("CheckinTime")));
			upInn.setCheckoutTime(Time.valueOf(request.getParameter("CheckoutTime")));
			innDao.upDateInn(upInn);

		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		request.setAttribute("inn", upInn);
		return request;
	}

	//宿追加
	private HttpServletRequest addInn(HttpServletRequest request) {
		InnDao innDao = new InnDao();
		InnBean addInn = new InnBean();
		try {
			addInn.setInnName(request.getParameter("InnName"));
			addInn.setCategoryCode(Integer.parseInt(request.getParameter("CategoryCode")));
			addInn.setInnPostalCode((Integer.parseInt(request.getParameter("InnPostalCode"))));
			addInn.setInnAddress(request.getParameter("InnAddress"));
			addInn.setCheckinTime(Time.valueOf(request.getParameter("CheckinTime")));
			addInn.setCheckoutTime(Time.valueOf(request.getParameter("CheckoutTime")));
			innDao.addInn(addInn);

		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return request;
	}

	//宿削除
	private HttpServletRequest deleteInn(HttpServletRequest request) {
		InnDao innDao = new InnDao();
		try {
			int innId = Integer.parseInt(request.getParameter("innId"));
			innDao.deleteInn(innId);

			return request;
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return request;
	}
}