package servlet;

import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.CategoryBean;
import bean.InnBean;
import bean.PlanBean;
import bean.SearchPlanBean;
import dao.CategoryDao;
import dao.InnDao;
import dao.PlanDao;
import tools.ServletTools;

/**
 * Servlet implementation class PlanListServlet
 */
@WebServlet("/plan")
public class plan extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public plan() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		// 一覧表示とかはこっち
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		String action = request.getParameter("action");
		System.out.println("doGet action : " + action);
		if (ServletTools.equalString(action, "searchList")) {
			ServletTools.viewPage("/plan/plans.jsp", searchList(request, 5), response);
		} else if (ServletTools.equalString(action, "detail")) {
			ServletTools.viewPage("/plan/planDetail.jsp", detailPlan(request), response);
		} else if (ServletTools.equalString(action, "addPlan")) {
			//プランの登録を開始する
			ServletTools.viewPage("/plan/chooseInn.jsp", request, response);
		} else if (ServletTools.equalString(action, "edit")) {
			//編集に入る
			ServletTools.viewPage("/plan/edit.jsp", detailPlan(request), response);
		} else {
			ServletTools.viewPage("/plan/searchPlan.jsp", request, response);
		}
	}

	private InnBean innSearch(HttpServletRequest request) {
		// TODO 自動生成されたメソッド・スタブ
		String innName = request.getParameter("innName");
		String innAddress = request.getParameter("innAddress");
		InnBean inn = InnDao.searchInnForPlan(innName, innAddress);
		return inn;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//更新・アップデート系
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		String action = request.getParameter("action");
		System.out.println("doPost action : " + action);

		if (ServletTools.equalString(action, "edit")) {
			//編集に入る
			ServletTools.viewPage("/plan/edit.jsp", detailPlan(request), response);
		} else if (ServletTools.equalString(action, "check")) {
			// 編集の確認
			request.setAttribute("plan", makePlanBean(request));
			request.setAttribute("content", makePlanBean(request).getPlanContent().replace("\n", "<br>"));
			ServletTools.viewPage("/plan/check.jsp", request, response);
		} else if (ServletTools.equalString(action, "verify")) {
			// 編集を確定
			ServletTools.viewPage("/message.jsp", updatePlan(request), response);
		} else if (ServletTools.equalString(action, "innSearch")) {
			// 宿を選ぶ
			InnBean inn = innSearch(request);
			if (inn == null) {
				request.setAttribute("message", "当てはまる宿がないか、複数の宿が当てはまっています。もう一度やり直してください。");
				ServletTools.viewPage("/plan/chooseInn.jsp", request, response);
			} else {
				request.setAttribute("inn", inn);
				ServletTools.viewPage("/plan/add.jsp", request, response);
			}
		} else if (ServletTools.equalString(action, "checkAdd")) {
			// プランの内容を確認する
			PlanBean plan = makePlanBean(request);
			request.setAttribute("plan", plan);
			ServletTools.viewPage("/plan/checkAdd.jsp", request, response);
		} else if (ServletTools.equalString(action, "addVerify")) {
			//プランの追加を確定する
			PlanBean plan = makePlanBean(request);
			PlanDao dao = new PlanDao();
			request.setAttribute("plan", dao.addPlan(plan));
			ServletTools.viewPage("/plan/addPlanDetail.jsp", request, response);
		} else {
			doGet(request, response);
		}

	}

	private HttpServletRequest detailPlan(HttpServletRequest request) {
		int planId = -1;
		try {
			planId = Integer.parseInt(request.getParameter("planId"));
		} catch (NumberFormatException e) {
		}
		if (planId < 0) {
			request.setAttribute("message", "申し訳ありません。お探しのプランは見つかりませんでした。");
		} else {
			PlanBean plan = PlanDao.getPlan(planId);
			request.setAttribute("content", plan.getPlanContent().replace("\n", "<br>"));
			request.setAttribute("plan", plan);
		}
		return request;
	}

	private HttpServletRequest searchList(HttpServletRequest request, int step) {
		SearchPlanBean search = new SearchPlanBean();
		search.setPlanName(request.getParameter("planName"));
		search.setInnAddress(request.getParameter("pref"));
		search.setInnName(request.getParameter("innName"));
		try {
			search.setCategoryCode(Integer.parseInt(request.getParameter("categoryCode")));
		} catch (Exception e) {
		}
		Integer priceCode = -1;
		try {
			priceCode = Integer.parseInt(request.getParameter("price"));
		} catch (Exception e) {
		}
		switch (priceCode) {
		case 1:
			search.setLowPrice(0);
			search.setHighPrice(9999);
			break;
		case 2:
			search.setLowPrice(10000);
			search.setHighPrice(19999);
			break;
		case 3:
			search.setLowPrice(20000);
			search.setHighPrice(39999);
			break;
		case 4:
			search.setLowPrice(40000);
			search.setHighPrice(null);
			break;
		}
		search.setAdmin(true);//メンバーテーブルから管理者かどうか判断する。
		PlanDao planDao = new PlanDao();
		List<PlanBean> planList = new ArrayList<PlanBean>();
		System.out.println(search);
		int page = 1;
		try {
			page = Integer.parseInt(request.getParameter("page"));
		} catch (NumberFormatException e) {
		}
		planList = planDao.searchPlan(search, page - 1, step);
		//		System.out.println("Current Page : " + page);
		request.setAttribute("currentPage", page);
		//		System.out.println("maxPage : " + ((planDao.searchPlanCount(search) + step - 1) / step));
		request.setAttribute("maxPage", ((planDao.searchPlanCount(search) + step - 1) / step));
		for (PlanBean plan : planList) {
			System.out.println(plan);
		}
		request.setAttribute("planList", planList);
		return request;
	}

	@SuppressWarnings("unused")
	private HttpServletRequest addPlan(HttpServletRequest request) {
		PlanBean plan = makePlanBean(request);
		PlanDao dao = new PlanDao();
		plan = dao.addPlan(plan);
		return request;
	}

	private HttpServletRequest updatePlan(HttpServletRequest request) {
		// TODO 自動生成されたメソッド・スタブ
		PlanBean plan = makePlanBean(request);
		PlanDao dao = new PlanDao();
		dao.updatePlan(plan);
		request.setAttribute("message", "完了しました!");
		return request;
	}

	private PlanBean makePlanBean(HttpServletRequest request) {
		PlanBean plan = new PlanBean();
		plan.setPlanName(request.getParameter("planName"));
		plan.setPlanContent(request.getParameter("planName"));
		plan.setRemark(request.getParameter("planRemark"));
		plan.setPlanContent(request.getParameter("planContent"));
		try {
			plan.setCategoryCode(Integer.parseInt(request.getParameter("categoryCode")));
		} catch (NumberFormatException e) {
		}
		try {
			plan.setInnId(Integer.parseInt(request.getParameter("innId")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			plan.setPrice(Integer.parseInt(request.getParameter("price")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			plan.setRoomQuantity(Integer.parseInt(request.getParameter("roomQuantity")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		try {
			plan.setDeleteDate(Date.valueOf(request.getParameter("date")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			plan.setPlanId(Integer.parseInt(request.getParameter("planId")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return plan;
	}

	@Override
	public void init() throws ServletException {
		System.out.println("アプリケーションスコープへ");
		List<CategoryBean> categories = CategoryDao.findAllCategory();
		getServletContext().setAttribute("categories", categories);
	}
}
