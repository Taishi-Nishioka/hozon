package servlet;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.PlanBean;
import bean.ReservationBean;
import dao.PlanDao;
import dao.ReservationDao;
import exception.DAOException;
import tools.ServletTools;

/**
 * Servlet implementation class ReservationServlet
 */
@WebServlet("/reservation")
public class reservation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int PAGE_STEP = 5;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public reservation() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession(false);
		@SuppressWarnings("unused")
		int memberId = -1;
		try {
			if (!(session.getAttribute("loginMemberId") == null)) {
				//ログイン済かどうか
				request.setCharacterEncoding("UTF-8");
				memberId = (int) session.getAttribute("loginMemberId");
				String action = request.getParameter("action");
				//actionください
				if (ServletTools.equalString(action, "list")) {
					ServletTools.viewPage("/reservation/list.jsp", getList(request), response);
				} else { //actionがどれにも当てはまらない
					request.setAttribute("message", "エラーが発生しました");
					ServletTools.viewPage("message.jsp", request, response);
				}
			} else {
				//ログインしてない時
				ServletTools.viewPage("/login", request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("message", "予期しないエラーが発生しました");
			ServletTools.viewPage("message.jsp", request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession(false);

		//		doGet(request, response);
		try {
			if (!(session.getAttribute("loginMemberId") == null)) {
				//ログイン済かどうか
				request.setCharacterEncoding("UTF-8");
				int memberId = (int) session.getAttribute("loginMemberId");
				String action = request.getParameter("action");
				//actionください
				if (!(ReservationDao.canTakeReservation(memberId))) {
					//その人の5件以上の予約がある?
					request.setAttribute("message", "申し訳ありません。お客様はこれ以上のご予約をお取りになれません。");
					ServletTools.viewPage("message.jsp", request, response);
				} else if (ServletTools.equalString(action, "takeReservation")) {
					//データベース登録
					ReservationDao dao = new ReservationDao();
					ReservationBean bean = makeReservationBean(request);
					request.setAttribute("reservation", bean = dao.takeReservation(bean));
					request.setAttribute("plan", PlanDao.getPlan(bean.getPlanId()));
					ServletTools.viewPage("/reservation/done.jsp", request, response);
				} else if (ServletTools.equalString(action, "isEmpty")) {
					//日付から空きがあるか確認
					ServletTools.viewPage("/reservation/form.jsp", isEmpty(request), response);
				} else if (ServletTools.equalString(action, "check")) {
					//actionがcheck(部屋数入力後)
					ServletTools.viewPage("/reservation/reserved.jsp", check(request), response);
				} else if (ServletTools.equalString(action, "inputDate")) {
					//予約画面から遷移してくる
					PlanBean plan = PlanDao.getPlan(Integer.parseInt(request.getParameter("planId")));
					request.setAttribute("plan", plan);
					ServletTools.viewPage("/reservation/form.jsp", request, response);
				} else if (ServletTools.equalString(action, "cancel")) {
					//キャンセル確認
					ServletTools.viewPage("/reservation/checkCancel.jsp", checkCancel(request), response);
				} else if (ServletTools.equalString(action, "cancelReservation")) {
					//キャンセル処理
					ServletTools.viewPage("message.jsp", ReservationDao.cancel(request), response);
				} else {
					doGet(request, response);
				}
			}else {
				request.setAttribute("message", "ログインしてください");
				ServletTools.viewPage("/login", request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("message", "予期しないエラーが発生しました");
			ServletTools.viewPage("message.jsp", request, response);
		}
	}

	private HttpServletRequest getList(HttpServletRequest request) {
		//予約リストの表示
		int memberId = (int) request.getSession().getAttribute("loginMemberId");
		int page = 1;
		try {
			page = Integer.parseInt(request.getParameter("page"));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		request.setAttribute("currentPage", page);
		request.setAttribute("maxPage",
				(ReservationDao.getReservatioinsCount(memberId) + PAGE_STEP - 1) / PAGE_STEP);
		request.setAttribute("reservationList",
				ReservationDao.searchReservationsByMemberId(memberId, page, PAGE_STEP));
		return request;
	}

	private HttpServletRequest isEmpty(HttpServletRequest request) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		ReservationBean bean = makeReservationBean(request);
		int rooms = ReservationDao.emptyRooms(bean.getPlanId(), bean.getCheckinDate(), bean.getCheckoutDate());
		if (rooms == -1) {
			throw new DAOException("予約日付が不正です");
		}
		request.setAttribute("maxRooms", rooms);
		request.setAttribute("reservation", bean);
		request.setAttribute("plan", PlanDao.getPlan(bean.getPlanId()));
		return request;
	}

	private HttpServletRequest check(HttpServletRequest request) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		ReservationDao reservationDao = new ReservationDao(); //daoを動かしたい
		ReservationBean reservationBean = makeReservationBean(request);
		// ReservationDAO reservation = new ReservationDAO();  //daoを動かしたい
		reservationBean = reservationDao.takeReservation(reservationBean);
		request.setAttribute("reservation", reservationBean);
		request.setAttribute("plan", PlanDao.getPlan(reservationBean.getPlanId()));
		return request;
	}

	private ReservationBean makeReservationBean(HttpServletRequest request) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		HttpSession session = request.getSession(false);
		int memberId = (Integer) session.getAttribute("loginMemberId");
		String strcheckinDate = request.getParameter("checkinDate"); //sendの中身
		String strcheckoutDate = request.getParameter("checkoutDate");
		int planId = -1;
		int roomQuantity = -1;
		ReservationBean reservationBean = new ReservationBean(); //beanを作りたい（DAOにあげたいから）
		try { //数字じゃないの入ってきた
			planId = Integer.parseInt(request.getParameter("planId")); //planIdをint
			if (request.getParameter("roomQuantity") == null) {
				roomQuantity = -1;
			} else {
				roomQuantity = Integer.parseInt(request.getParameter("roomQuantity"));
			} //部屋数intに変える
			reservationBean.setCheckinDate(java.sql.Date.valueOf(LocalDate.parse(strcheckinDate)));
			reservationBean.setCheckoutDate(java.sql.Date.valueOf(LocalDate.parse(strcheckoutDate)));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		reservationBean.setMemberId(memberId);
		reservationBean.setPlanId(planId);
		reservationBean.setRoomQuantity(roomQuantity);

		return reservationBean;
	}

	public static HttpServletRequest checkCancel(HttpServletRequest request) {
		// TODO 自動生成されたメソッド・スタブ
		try {
			int reservationId = Integer.parseInt(request.getParameter("reservationId"));
			request.setAttribute("reservation", ReservationDao.getReservatioinDetail(reservationId));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return request;
	}

}
