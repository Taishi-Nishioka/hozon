import java.sql.Time;

import bean.InnBean;
import dao.InnDao;

/*public class TestInn {
	public static void main(String[] args) {
		InnDAO innDao = new InnDAO();
		InnBean searchingInn = new InnBean();
		List<InnBean> innList = new ArrayList<InnBean>();
		searchingInn.setInnName("星野リゾート");
		innList = innDao.searchInn(searchingInn);
		for (InnBean inn : innList) {
			System.out.println(inn.toString());
			System.out.println(inn.getInnAddress().replace("\n", "<br>"));
		}
	}
}
*/
//追加
/*public class TestInn {
	public static void main(String[] args) {
		InnDAO innDao = new InnDAO();
		InnBean addInn = new InnBean();
		addInn.setInnName("星野リゾート");
		addInn.setCategoryCode(2);
		addInn.setInnPostalCode(1234567);
		addInn.setInnAddress("金沢県のどこか");
		addInn.setCheckinTime(Time.valueOf("10:00:00"));
		addInn.setCheckoutTime(Time.valueOf("23:00:00"));
		innDao.addInn(addInn); // DAOにGO
	}
}*/

/*
//宿の詳細をIDから
public class TestInn {
	public static void main(String[] args) {
		InnDAO innDao = new InnDAO();
		int i = 1;

		InnBean searchingInnId = innDao.searchInnById(i);
		searchingInnId.setInnId(i);

		System.out.println(searchingInnId.toString());
		System.out.println(searchingInnId.getInnAddress());

}
}
*/

public class TestInn {
	public static void main(String[] args) {

		InnDao innDao = new InnDao();
		InnBean upInn = new InnBean();
		upInn.setInnId(8);

		upInn.setInnName("星野リゾートMM");
		upInn.setCategoryCode(1);
		upInn.setInnPostalCode(9876543);
		upInn.setInnAddress("日本のどこか");
		upInn.setCheckinTime(Time.valueOf("9:00:00"));
		upInn.setCheckoutTime(Time.valueOf("22:00:00"));
		innDao.upDateInn(upInn);

	}
}

