import dao.MemberDao;

public class TestMember {
	public static void main(String[] args) {
		/*		SearchMemberBean search = new SearchMemberBean();
				search.setAdmin(true);
				MemberDao memberDao = new MemberDao();
				List<MemberBean> memberList = new ArrayList<MemberBean>();

				SearchMemberBean searchingMember = new SearchMemberBean();
				searchingMember.setMemberName("安倍晋三");

				memberList = memberDao.searchMember(searchingMember);
				for (MemberBean members : memberList) {
					System.out.println(members.toString());
					System.out.println(members.getMemberName().replace("\n", "<br>"));*/

		MemberDao dao = new MemberDao();
/*		MemberBean member = dao.login("abeshinzo@yahoo.co.jp", "4kiechan");
		System.out.println(member);*/

		dao.withdraw(4);
	}
}