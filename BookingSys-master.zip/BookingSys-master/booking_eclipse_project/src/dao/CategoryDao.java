package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CategoryBean;
import exception.DAOException;
import tools.MDBC;

public class CategoryDao {
	public static List<CategoryBean> findAllCategory() {
		List<CategoryBean> categories = new ArrayList<CategoryBean>();
		String sql = "SELECT * FROM category";
		try( Connection con = MDBC.getConnection() ; PreparedStatement ps = con.prepareStatement(sql) ; ResultSet rs = ps.executeQuery()){
			while(rs.next()) {
				categories.add(new CategoryBean(rs.getInt("category_code"), rs.getString("category_name")));
				System.out.println(rs.getInt("category_code") + ":" + rs.getString("category_name"));
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return categories;
	}
}
