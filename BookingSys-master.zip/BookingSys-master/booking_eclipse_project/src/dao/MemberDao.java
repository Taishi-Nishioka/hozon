package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import bean.MemberBean;
import exception.DAOException;
import tools.MDBC;

public class MemberDao {
	public MemberDao() {
		super();
	}

	public List<MemberBean> searchMember(MemberBean member) {
		List<MemberBean> members = new ArrayList<MemberBean>();
		String sql = "SELECT * FROM member WHERE member_id >= 0";
		//プレースホルダあり
		if (member.getMemberID() != null ) {
			sql = sql + " AND member_id = " + member.getMemberID();
		}

		if (member.getMemberName() != null || member.getMemberName().length() > 0) {
			sql = sql + " AND name LIKE ?";
		}

		if (member.getMemberAddress() != null || member.getMemberAddress().length() > 0) {
			sql = sql + " AND address LIKE ?";
		}

		if (member.getPhoneNum() != null || member.getPhoneNum().length() > 0) {
			sql = sql + " AND phone_number LIKE ?";
		}

		if (member.getEmail() != null || member.getEmail().length() > 0) {
			sql = sql + " AND email LIKE ?";
		}
		sql = sql + " ORDER BY member_id";
		//		System.out.println(sql);  // 構成したSQL文の確認
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) { //コネクションの取得(try-with-resource)
			int follow = 1;


			if (member.getMemberName() != null || member.getMemberName().length() > 0) {
				ps.setString(follow++, "%" + member.getMemberName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}

			if (member.getMemberAddress() != null || member.getMemberAddress().length() > 0) {
				ps.setString(follow++, "%" + member.getMemberAddress() + "%");
			}

			if (member.getPhoneNum() != null || member.getPhoneNum().length() > 0) {
				ps.setString(follow++, "%" + member.getPhoneNum() + "%");
			}

			if (member.getEmail() != null || member.getEmail().length() > 0) {
				ps.setString(follow++, "%" + member.getEmail() + "%");
			}
		System.out.println(sql);
			try (ResultSet rs = ps.executeQuery()) { //	SQL実行結果の取得(try-with-resource)
				while (rs.next()) {//取り込んだデータをMemberBeanに設定
					members.add(rsToMember(rs));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			e.printStackTrace();
		}
		return members;
	}

	//ID検索

	public static MemberBean searchMemberById(int memberId) {

		String sql = "SELECT name, postalcode, address, phone_number, email, birthday "
				+ "FROM member " +  "WHERE member_id = " + memberId;
		MemberBean member = new MemberBean();
		member.setMemberID(memberId);
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					member.setMemberName(rs.getString("name"));
					member.setMemberPostalCode(rs.getInt("postalcode"));
					member.setMemberAddress(rs.getString("address"));
					member.setPhoneNum(rs.getString("phone_number"));
					member.setEmail(rs.getString("email"));
					member.setBirthday(rs.getDate("birthday"));
					return member;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return member;
	}

	//会員情報の更新
	public MemberBean updateMember(MemberBean member) {
		//MemberBean members = new MemberBean();
		String sql = "UPDATE member SET name = ?, postalcode = ?, "
				+ "address = ?, phone_number = ?, email = ?"
				+ ", birthday = ? , password = ? WHERE member_id = " + member.getMemberID();

		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) { //コネクションの取得(try-with-resource)

			int follow = 1;

			ps.setString(follow++, member.getMemberName()); //プレースホルダに設定
			ps.setInt(follow++, member.getMemberPostalCode());
			ps.setString(follow++, member.getMemberAddress());
			ps.setString(follow++, member.getPhoneNum());
			ps.setString(follow++, member.getEmail());
			ps.setDate(follow++, member.getBirthday());
			ps.setString(follow++, member.getPassword());
			System.out.println(ps);
			int line = ps.executeUpdate();

			System.out.println(line + "行更新しました。");
			//if(ps.executeUpdate() == 1) {	//	SQL実行結果の取得(try-with-resource)
			/*while (next()) {//取り込んだデータをMemberBeanに設定
				MemberBean UpdateMembers = new MemberBean();
				UpdateMembers.setMemberID(rs.getInt("member_id"));
				UpdateMembers.setMemberName(rs.getString("name"));
				UpdateMembers.setMemberPostalCode(rs.getInt("postalcode"));
				UpdateMembers.setPhoneNum(rs.getString("phone_number"));
				UpdateMembers.setMemberAddress(rs.getString("address"));
				UpdateMembers.setEmail(rs.getString("email"));
				UpdateMembers.setBirthday(rs.getDate("birthday"));
				UpdateMembers.setJoinDate(rs.getDate("join_date"));
				UpdateMembers.setLeaveDate(rs.getDate("leave_date"));
				members.add(UpdateMembers);
			}
			 */
		} catch (SQLException e) {

			e.printStackTrace();

		} catch (DAOException e) {

			e.printStackTrace();
		}
		return member;
	}

	//新規会員登録

	public MemberBean signUp(MemberBean member) {
		String sql = "INSERT INTO member (name, postalcode, address, phone_number, "
				+ "email, birthday, join_date, password, admin)"
				+ " VALUES(?, ?, ?, ?, ?, ?, CURRENT_DATE, ?, false)";

		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			//コネクションの取得(try-with-resource)
			int follow = 1;

			ps.setString(follow++, member.getMemberName()); //プレースホルダに設定
			ps.setInt(follow++, member.getMemberPostalCode());
			ps.setString(follow++, member.getMemberAddress());
			ps.setString(follow++, member.getPhoneNum());
			ps.setString(follow++, member.getEmail());
			ps.setDate(follow++, member.getBirthday());
			ps.setString(follow++, member.getPassword());

			ps.executeUpdate();
			//String message = "登録完了";

		}catch(Exception e) {}
		sql = "SELECT member_id FROM member WHERE email = ?";
		try(Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)){
			ps.setString(1, member.getEmail());
			try(ResultSet rs = ps.executeQuery()){
				if(rs.next()) {
					member.setMemberID(rs.getInt(1));
				}
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return member;

	}

	public MemberBean login(String email, String password) {
		MemberBean member = null;
		String sql = "SELECT * FROM member * WHERE email = ? AND password = ? AND leave_date IS NULL";
		try (Connection con = MDBC.getConnection() ; PreparedStatement ps = con.prepareStatement(sql)){
			ps.setString(1, email);
			ps.setString(2, password);
			try(ResultSet rs = ps.executeQuery()){
				if(rs.next()) {
					member = rsToMember(rs);
				}
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return member;
	}


	public static boolean withdraw(int memberId) {
		boolean f = false;
		LocalDate today = LocalDate.now();
		String sql = "UPDATE member SET leave_date = ? WHERE member_id = " + memberId;
		try(Connection con = MDBC.getConnection() ; PreparedStatement ps = con.prepareStatement(sql)){
			ps.setDate(1, java.sql.Date.valueOf(today));
			if ( ps.executeUpdate() == 1) {
				f = true;
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return f;
	}

	private MemberBean rsToMember(ResultSet rs) throws SQLException{
		MemberBean member = new MemberBean();
		member.setMemberID(rs.getInt("member_id"));
		member.setMemberName(rs.getString("name"));
		member.setMemberPostalCode(rs.getInt("postalcode"));
		member.setPhoneNum(rs.getString("phone_number"));
		member.setMemberAddress(rs.getString("address"));
		member.setEmail(rs.getString("email"));
		member.setBirthday(rs.getDate("birthday"));
		member.setJoinDate(rs.getDate("join_date"));
		member.setLeaveDate(rs.getDate("leave_date"));
		member.setAdmin(rs.getBoolean("admin"));
		return member;
	}


}
