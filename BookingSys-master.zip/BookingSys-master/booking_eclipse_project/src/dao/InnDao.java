package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.InnBean;
import exception.DAOException;
import tools.MDBC;

public class InnDao {
	////// 管理者が宿検索 //宿名,住所,分類
	public List<InnBean> searchInn(InnBean inn, int page, int step) {
		List<InnBean> Inns = new ArrayList<InnBean>();
		String sql = "SELECT inn_id, inn_name, category_code, inn_postalcode, inn_address, checkin_time, checkout_time "
				+ "FROM inn " + "NATURAL JOIN category " + "WHERE inn_id > 0 ";

		if (inn.getInnName() != null && inn.getInnName().length() > 0 ) {
			sql = sql + " AND inn_name LIKE ?"; // 宿名
		}
		if (inn.getInnAddress() != null && inn.getInnAddress().length() > 0) {
			sql = sql + " AND inn_address LIKE ?"; // 住所
		}
		if(inn.getInnPostalCode() != null && inn.getInnPostalCode() > 0) {
			sql = sql + " AND inn_postalcode =" + inn.getInnPostalCode();
		}

		sql = sql + " ORDER BY inn_id" + " OFFSET " + (page * step) + " LIMIT " + step;

		// System.out.println(sql); // 構成したSQL文の確認
		System.out.println(sql);
		try (Connection con = MDBC.getConnection(); // dbの接続するやつ外部から
				PreparedStatement ps = con.prepareStatement(sql)) { // いつもの
			// コネクションの取得(try-with-resource)
			int follow = 1; // 文を付け足す感じ i++みたいな ?がいくつだかわからないから設定している?
			//////////////////// 宿名
			if (inn.getInnName() != null && inn.getInnName().length() > 0 ) {
				ps.setString(follow++, "%" + inn.getInnName() + "%");
				// ワイルドカードを設定しつつ、プレースホルダに設定
			}
			//////////////////// 住所
			if (inn.getInnAddress() != null && inn.getInnAddress().length() > 0) {
				ps.setString(follow++, "%" + inn.getInnAddress() + "%");
				// ワイルドカードを設定しつつ、プレースホルダに設定
			}

			//////////////////////////////// いつもの
			try (ResultSet rs = ps.executeQuery()) { // SQL実行結果の取得(try-with-resource)

				while (rs.next()) {// 取り込んだデータをInnBeanに設定

					InnBean searchedInn = new InnBean(); // p.224に記載
					searchedInn.setInnId(rs.getInt("inn_id"));
					searchedInn.setInnName(rs.getString("inn_name"));
					searchedInn.setCategoryCode(rs.getInt("category_code"));
					searchedInn.setInnPostalCode(rs.getInt("inn_postalcode"));
					searchedInn.setInnAddress(rs.getString("inn_address"));
					searchedInn.setCheckinTime(rs.getTime("checkin_time"));
					searchedInn.setCheckoutTime(rs.getTime("checkout_time"));
					Inns.add(searchedInn);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return Inns;
	}

	/////名前と住所で宿検索
	public static InnBean searchInnForPlan(String innName, String innAddress) {
		String sql = "SELECT * FROM inn WHERE inn_name LIKE ? AND inn_address LIKE ?";
		InnBean bean = null;
		try(Connection con = MDBC.getConnection() ; PreparedStatement ps = con.prepareStatement(sql)){
			ps.setString(1, innName);
			ps.setString(2, "%" +innAddress + "%");
			try ( ResultSet rs = ps.executeQuery()){
				int count = 0;
				while (rs.next()){
					bean = new InnBean();
					bean.setInnId(rs.getInt("inn_id"));
					bean.setInnName(rs.getString("inn_name"));
					bean.setCategoryCode(rs.getInt("category_code"));
					bean.setInnPostalCode(rs.getInt("inn_postalcode"));
					bean.setInnAddress(rs.getString("inn_address"));
					bean.setCheckinTime(rs.getTime("checkin_time"));
					bean.setCheckoutTime(rs.getTime("checkout_time"));
					if (count > 1) {
						return null;
					}
				}
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return bean;
	}

	///// 宿追加
	public InnBean addInn(InnBean inn) {
		// シリアル値を取得
		String sql = "SELECT nextval('inn_inn_id_seq')";// 場所指定
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					inn.setInnId(rs.getInt(1));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			// 自動生成された catch ブロック
			e.printStackTrace();
		}
		// データの入力
		sql = "INSERT INTO inn(inn_id, inn_name, category_code, inn_postalcode, inn_address, checkin_time, checkout_time) "
				+ "values(?,?,?,?,?,?,?)";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, inn.getInnId());
			ps.setString(2, inn.getInnName());
			ps.setInt(3, inn.getCategoryCode());
			ps.setInt(4, inn.getInnPostalCode());
			ps.setString(5, inn.getInnAddress());
			ps.setTime(6, inn.getCheckinTime());
			ps.setTime(7, inn.getCheckoutTime());
			if (ps.executeUpdate() == 0) {
				return null;
			}
			return inn;
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return null;
		}
	}

	//// 宿の詳細をIDから
	public InnBean searchInnById(int InnID) {
		String sql = "SELECT inn_name, category_code, inn_postalcode, inn_address, checkin_time, checkout_time "
				+ "FROM inn " + "NATURAL JOIN category " + "WHERE inn_id = "+InnID;
		InnBean inn = new InnBean();
		inn.setInnId(InnID);
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					inn.setInnName(rs.getString("inn_name"));
					inn.setCategoryCode(rs.getInt("category_code"));
					inn.setInnPostalCode(rs.getInt("inn_postalcode"));
					inn.setInnAddress(rs.getString("inn_address"));
					inn.setCheckinTime(rs.getTime("checkin_time"));
					inn.setCheckoutTime(rs.getTime("checkout_Time"));
					return inn;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		} catch (DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return inn;
	}

	// 変更文
	public InnBean upDateInn(InnBean inn) {
		String sql = "UPDATE inn SET inn_name = ?, category_code = ?, inn_postalcode = ?,"
				+ " inn_address = ?, checkin_time = ?, checkout_time = ?"
				+ " WHERE inn_id = " + inn.getInnId() ;
		System.out.println(sql);
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

				ps.setString(1, inn.getInnName());
				ps.setInt(2, inn.getCategoryCode());
				ps.setInt(3, inn.getInnPostalCode());
				ps.setString(4, inn.getInnAddress());
				ps.setTime(5, inn.getCheckinTime());
				ps.setTime(6, inn.getCheckoutTime());

				if (ps.executeUpdate() == 0) {
					return null;
				}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return inn;
	}


	//宿削除
	public int deleteInn(int InnID) {
		String sql = "DELETE FROM inn WHERE inn_id = " + InnID;
		System.out.println(sql);
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {

			int rows = ps.executeUpdate();

			return rows;

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return -1;
	}

	//ページのカウント
	public int searchInnCount(InnBean inn) {
		int count = -1;
		String sql = "SELECT COUNT(*) FROM inn NATURAL JOIN category WHERE inn_id > 0";
		sql = makeSql(sql, inn);
		//		System.out.println(sql);  // 構成したSQL文の確認
//		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) { //コネクションの取得(try-with-resource)
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			int follow = 1;
			if (inn.getInnName() != null && inn.getInnName().length() > 0) {
				ps.setString(follow++, "%" + inn.getInnName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (inn.getInnAddress() != null && inn.getInnAddress().length() > 0) {
				ps.setString(follow++, "%" + inn.getInnAddress() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (inn.getInnPostalCode() != null && inn.getInnPostalCode() > 0) {
				ps.setString(follow++, "%" + inn.getInnPostalCode() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			try (ResultSet rs = ps.executeQuery()) { //	SQL実行結果の取得(try-with-resource)
				if (rs.next()) {
					count = rs.getInt(1);
				} //取り込んだデータをPlanBeanに設定
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			e.printStackTrace();
		}
		return count;
	}

	private String makeSql(String sql, InnBean inn) {
		//検索項目に応じて条件を設定(プレースホルダあり)
		if (inn.getInnName() != null && inn.getInnName().length() > 0 ) {
			sql = sql + " AND inn_name LIKE ?"; // 宿名
		}
		if (inn.getInnAddress() != null && inn.getInnAddress().length() > 0) {
			sql = sql + " AND inn_address LIKE ?"; // 住所
		}
		if(inn.getInnPostalCode() != null && inn.getInnPostalCode() > 0) {
			sql = sql + " AND inn_postalcode " + inn.getInnPostalCode();
		}
		return sql;
	}
}
