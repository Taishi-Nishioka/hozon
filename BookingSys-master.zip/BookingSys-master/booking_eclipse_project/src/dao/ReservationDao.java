package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import bean.ReservationBean;
import bean.ReservationDetailBean;
import exception.DAOException;
import tools.MDBC;

public class ReservationDao {

	public ReservationBean takeReservation(ReservationBean reservation) {
		//次の予約IDをとる
		String sql = "SELECT nextval('reservation_reservation_id_seq')";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					reservation.setReservationId(rs.getInt(1));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		//SQL文の準備
		sql = "INSERT INTO reservation (member_id, plan_id, reservation_id, checkin_date, checkout_date, room_quantity, reserved_time, cancel) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, reservation.getMemberId());
			ps.setInt(2, reservation.getPlanId());
			ps.setInt(3, reservation.getReservationId());
			ps.setDate(4, reservation.getCheckinDate());
			ps.setDate(5, reservation.getCheckoutDate());
			ps.setInt(6, reservation.getRoomQuantity());
			reservation.setReservedTime(Timestamp.valueOf(LocalDateTime.now()));
			ps.setTimestamp(7, reservation.getReservedTime());
			reservation.setCancel(false);
			ps.setBoolean(8, reservation.isCancel());
			//SQLの実行
			if (ps.executeUpdate() == 0) {
				return null;
			}
			//取得した予約情報をリターン
			return reservation;
		} catch (Exception e) {
			e.printStackTrace();
			//	throw new DAOException("");
			return null;
		}
	}

	public static boolean canTakeReservation(int memberId) {
		//メンバーIDから、予約が5件以上あるかどうかチェック
		String sql = "SELECT count(*) FROM reservation WHERE member_id= " + memberId + "   AND checkout_date > ?";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			//プレースホルダに「今日」を設定
			ps.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			//SQL文を実行
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					if (rs.getInt(1) > 5) {
						//予約が5件を超えるため予約不可
						return false;
					} else {
						//予約が5件以下なので予約可
						return true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;//値が帰ってこなかった時も不可
	}

	public static int emptyRooms(int plan, java.sql.Date checkin_date, java.sql.Date checkout_date) {
		//SQLの実行
		String sql = String.format("SELECT room_quantity FROM reservation WHERE plan_id = %d AND"
				+ " NOT ((checkin_date >= ? AND checkout_date >= ?)"
				+ " OR (checkout_date <= ? AND checkin_date <= ?))", plan);
		if (checkout_date.compareTo(checkin_date) <= 0) {
			return -1;
		}
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setDate(1, checkout_date);
			ps.setDate(2, checkout_date);
			ps.setDate(3, checkin_date);
			ps.setDate(4, checkin_date);
			System.out.println(ps);
			try (ResultSet rs = ps.executeQuery()) {
				//部屋カウント用の変数roomsを用意
				int rooms = 0;
				while (rs.next()) {
					//各予約の部屋数を足していく
					rooms += rs.getInt("room_quantity");
				}
				rooms = PlanDao.getPlan(plan).getRoomQuantity() - rooms; //空き部屋数を数える（プランの最大部屋数から、予約の部屋数を引く）
				if (rooms < 0) {
					//残り部屋数が-なら0を返す。
					return 0;
				} else {
					//プランの残り部屋数を返す
					return rooms;

				}
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		//該当のプランが存在しない時、その他の要因によりreturnまで到達しなかった時は-1を返す
		return -1;
	}

	public static void withdraw(int memberId) {
		// TODO 自動生成されたメソッド・スタブ
		String sql = "UPDATE reservation SET cancel = true WHERE checkin_date >= ? AND member_id = " + memberId;
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
			ps.executeUpdate();
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}

	public static List<ReservationDetailBean> searchReservationsByMemberId(int memberId, int page, int step) {
		List<ReservationDetailBean> reservationList = new ArrayList<ReservationDetailBean>();
		String sql = "SELECT * FROM reservation NATURAL JOIN plan NATURAL JOIN inn WHERE member_id = " + memberId
				+ " ORDER BY checkin_date OFFSET " + (page - 1) * step + "LIMIT " + step;
		try (Connection con = MDBC.getConnection();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			System.out.println(ps);
			while (rs.next()) {
				reservationList.add(resultToJoinedBean(rs));
			}
		} catch (SQLException | DAOException e) {
			e.printStackTrace();
		}
		return reservationList;
	}

	@SuppressWarnings("unused")
	private static ReservationBean resultToBean(ResultSet rs) throws SQLException {
		ReservationBean reservation = new ReservationBean();
		reservation.setCancel(rs.getBoolean("cancel"));
		reservation.setCheckinDate(rs.getDate("chechin_date"));
		reservation.setCheckoutDate(rs.getDate("checkout_date"));
		reservation.setMemberId(rs.getInt("member_id"));
		reservation.setPlanId(rs.getInt("plan_id"));
		reservation.setReservationId(rs.getInt("reservation_id"));
		reservation.setReservedTime(rs.getTimestamp("reserved_time"));
		reservation.setRoomQuantity(rs.getInt("room_quantity"));
		return reservation;
	}

	private static ReservationDetailBean resultToJoinedBean(ResultSet rs) throws SQLException {
		ReservationDetailBean reservation = new ReservationDetailBean();
		reservation.setCancel(rs.getBoolean("cancel"));
		reservation.setCheckinDate(rs.getDate("checkin_date"));
		reservation.setCheckoutDate(rs.getDate("checkout_date"));
		reservation.setMemberId(rs.getInt("member_id"));
		reservation.setPlanId(rs.getInt("plan_id"));
		reservation.setReservationId(rs.getInt("reservation_id"));
		reservation.setReservedTime(rs.getTimestamp("reserved_time"));
		reservation.setRoomQuantity(rs.getInt("room_quantity"));
		reservation.setPlanName(rs.getString("plan_name"));
		reservation.setInnName(rs.getString("inn_name"));
		reservation.setPrice(rs.getInt("price"));
		return reservation;
	}

	public static int getReservatioinsCount(int memberId) {
		// TODO 自動生成されたメソッド・スタブ
		String sql = "SELECT count(*) FROM reservation NATURAL JOIN plan NATURAL JOIN inn WHERE member_id = "
				+ memberId;
		try (Connection con = MDBC.getConnection();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			if (rs.next()) {
				return rs.getInt(1);
			} else {
				return -1;
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return -1;
		}
	}

	public static ReservationDetailBean getReservatioinDetail(int reservationId) {
		// TODO 自動生成されたメソッド・スタブ
		String sql = "SELECT * FROM reservation NATURAL JOIN plan NATURAL JOIN inn WHERE reservation_id = " + reservationId;
		try (Connection con = MDBC.getConnection();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			if (rs.next()) {
				return resultToJoinedBean(rs);
			} else {
				return null;
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return null;
		}
	}

	public static HttpServletRequest cancel(HttpServletRequest request) {
		// TODO 自動生成されたメソッド・スタブ
		try {
			String sql = "UPDATE reservation SET cancel = true WHERE reservation_id = "
					+ Integer.parseInt(request.getParameter("reservationId"));
			try(Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)){
				if(ps.executeUpdate() == 1) {
					request.setAttribute("message", "正常にキャンセル処理が完了しました");
				}else {
					request.setAttribute("message", "キャンセル処理が失敗しました");
				}
			} catch (SQLException | DAOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
				request.setAttribute("message", "キャンセル処理が失敗しました");
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			request.setAttribute("message", "キャンセル処理が失敗しました");
		}
		return request;
	}
}
