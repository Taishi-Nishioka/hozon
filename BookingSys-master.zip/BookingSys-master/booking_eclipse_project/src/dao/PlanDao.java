package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.PlanBean;
import bean.SearchPlanBean;
import exception.DAOException;
import tools.MDBC;

public class PlanDao {

	public PlanDao() {
		super();
	}

	public int searchPlanCount(SearchPlanBean plan) {
		int count = -1;
		String sql = "SELECT COUNT(*) FROM plan NATURAL JOIN inn NATURAL JOIN category";
		sql = makeSql(sql, plan);
		//		System.out.println(sql);  // 構成したSQL文の確認
		//		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) { //コネクションの取得(try-with-resource)
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			int follow = 1;
			if (notNull(plan.getPlanName())) {
				ps.setString(follow++, "%" + plan.getPlanName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (notNull(plan.getInnName())) {
				ps.setString(follow++, "%" + plan.getInnName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (notNull(plan.getInnAddress())) {
				ps.setString(follow++, "%" + plan.getInnAddress() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			System.out.println(ps);
			try (ResultSet rs = ps.executeQuery()) { //	SQL実行結果の取得(try-with-resource)
				if (rs.next()) {
					count = rs.getInt("count");
				} //取り込んだデータをPlanBeanに設定
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			e.printStackTrace();
		}
		return count;
	}

	public List<PlanBean> searchPlan(SearchPlanBean plan, int page, int step) {
		List<PlanBean> plans = new ArrayList<PlanBean>();
		String sql = "SELECT * FROM plan NATURAL JOIN inn NATURAL JOIN category";
		sql = makeSql(sql, plan);
		sql = sql + " ORDER BY plan_id" + " OFFSET " + (page * step) + " LIMIT " + step;
		//		System.out.println(sql);  // 構成したSQL文の確認
		//		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) { //コネクションの取得(try-with-resource)
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			int follow = 1;
			if (notNull(plan.getPlanName())) {
				ps.setString(follow++, "%" + plan.getPlanName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (notNull(plan.getInnName())) {
				ps.setString(follow++, "%" + plan.getInnName() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			if (notNull(plan.getInnAddress())) {
				ps.setString(follow++, "%" + plan.getInnAddress() + "%");//ワイルドカードを設定しつつ、プレースホルダに設定
			}
			System.out.println(ps);
			try (ResultSet rs = ps.executeQuery()) { //	SQL実行結果の取得(try-with-resource)
				while (rs.next()) {//取り込んだデータをPlanBeanに設定
					PlanBean planBean = rsToPlan(rs);
					String content = planBean.getPlanContent().replace("\n", "<br>");
					int split = 200;
					if (content.length() > split) {
						planBean.setPlanContent(content.substring(0, split) + "......");
					}
					planBean.setPlanContent(planBean.getPlanContent().replace("\n", "<br>"));
					plans.add(planBean);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return plans;
	}

	public PlanBean addPlan(PlanBean plan) {
		// 次のシリアル値を取得
		String sql = "SELECT nextval('plan_plan_id_seq')";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					plan.setPlanId(rs.getInt(1));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		// データの入力
		sql = "INSERT INTO plan(plan_id, inn_id, plan_name, plan_content, price, room_capacity, delete_date, plan_remark) VALUES(?, ?, ?, ?, ? ,? ,? ,?)";
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, plan.getPlanId());
			ps.setInt(2, plan.getInnId());
			ps.setString(3, plan.getPlanName());
			ps.setString(4, plan.getPlanContent());
			ps.setInt(5, plan.getPrice());
			ps.setInt(6, plan.getRoomQuantity());
			ps.setDate(7, plan.getDeleteDate());
			ps.setString(8, plan.getRemark());
			if (ps.executeUpdate() == 0) {
				return null;
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return null;
		}
		return getPlan(plan.getPlanId());
	}

	public PlanBean updatePlan(PlanBean plan) {
		String sql = "UPDATE plan SET plan_name = ?, plan_content = ?, inn_id = ?, price = ?, room_capacity = ?, delete_date = ?, plan_remark = ? WHERE plan_id = "
				+ plan.getPlanId();
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			//System.out.println(plan);
			plan = fillBean(plan);
			int follow = 1;
			ps.setString(follow++, plan.getPlanName());
			ps.setString(follow++, plan.getPlanContent());
			ps.setInt(follow++, plan.getInnId());
			ps.setInt(follow++, plan.getPrice());
			ps.setInt(follow++, plan.getRoomQuantity());
			ps.setDate(follow++, plan.getDeleteDate());
			ps.setString(follow++, plan.getRemark());
			if (ps.executeUpdate() == 0) {
				return null;
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return null;
		}
		return getPlan(plan.getPlanId());
	}

	public static PlanBean getPlan(int planId) {
		PlanBean plan = null;
		String sql = " SELECT * FROM plan NATURAL JOIN inn NATURAL JOIN category WHERE plan_id = " + planId;
		try (Connection con = MDBC.getConnection();
				PreparedStatement ps = con.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {
			if (rs.next()) {
				plan = rsToPlan(rs);
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			return null;
		}
		return plan;
	}

	public String getInnName(int innId) {
		String sql = "SELECT innName From inn WHERE inn_id = " + innId;
		try (Connection con = MDBC.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					return rs.getString(1);
				}
			}
		} catch (SQLException | DAOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		return null;
	}

	private static PlanBean rsToPlan(ResultSet rs) throws SQLException {
		PlanBean plan = new PlanBean();
		plan.setInnId(rs.getInt("inn_id"));
		plan.setInnName(rs.getString("inn_name"));
		plan.setPlanId(rs.getInt("plan_id"));
		plan.setPlanName(rs.getString("plan_name"));
		plan.setPlanContent(rs.getString("plan_content"));
		plan.setCategoryName(rs.getString("category_name"));
		plan.setCategoryCode(rs.getInt("category_code"));
		plan.setRoomQuantity(rs.getInt("room_capacity"));
		plan.setPrice(rs.getInt("price"));
		plan.setRemark(rs.getString("plan_remark"));
		return plan;
	}

	private String makeSql(String sql, SearchPlanBean plan) {
		//検索項目に応じて条件を設定(プレースホルダなし)
		if (plan.isAdmin()) {
			sql = sql + " WHERE plan_id > 0";
		} else {
			sql = sql + " WHERE delete_date IS NULL";
		}
		if (plan.getLowPrice() != null && plan.getHighPrice() != null) {
			sql = String.format("%s AND price BETWEEN %d AND %d", sql, plan.getLowPrice(), plan.getHighPrice());
		} else if (plan.getLowPrice() != null && plan.getHighPrice() == null) {
			sql = String.format("%s AND price > %d", sql, plan.getLowPrice());
		}
		if (plan.getCategoryCode() != null) {
			sql = sql + " AND category_code = " + plan.getCategoryCode();
		}
		//検索項目に応じて条件を設定(プレースホルダあり)
		if (notNull(plan.getPlanName())) {
			sql = sql + " AND plan_name LIKE ?";
		}
		if (notNull(plan.getInnName())) {
			sql = sql + " AND inn_name LIKE ?";
		}
		if (notNull(plan.getInnAddress())) {
			sql = sql + " AND inn_address LIKE ?";
		}
		return sql;
	}

	private boolean notNull(String str) {
		if (str != null && str.length() != 0) {
			return true;
		} else {
			return false;
		}
	}

	private PlanBean fillBean(PlanBean plan) {
		int planId = plan.getPlanId();
		PlanBean compare = getPlan(planId);
		if (plan.getInnId() == null) {
			plan.setInnId(compare.getInnId());
		}
		if (plan.getPlanName() == null) {
			plan.setPlanName(compare.getPlanName());
		}
		if (plan.getPlanContent() == null) {
			plan.setPlanContent(compare.getPlanContent());
		}
		if (plan.getPrice() == null) {
			plan.setPrice(compare.getPrice());
		}
		if (plan.getRoomQuantity() == null) {
			plan.setRoomQuantity(compare.getRoomQuantity());
		}
		if (plan.getDeleteDate() == null) {
			plan.setDeleteDate(compare.getDeleteDate());
		}
		if (plan.getRemark() == null) {
			plan.setRemark(compare.getRemark());
		}
		return plan;
	}

}
