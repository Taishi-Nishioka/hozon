import dao.PlanDao;

public class TestPlan {
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		PlanDao planDao = new PlanDao();

//------------------------------------------------------ 検索テスト------------------------------------------------------
/*		SearchPlanBean search = new SearchPlanBean();
		search.setAdmin(true);
		List<PlanBean> planList = new ArrayList<PlanBean>();

		SearchPlanBean searchingPlan = new SearchPlanBean();
		searchingPlan.setInnName("大川荘");
		searchingPlan.setInnAddress("福島県");

		planList = planDao.searchPlan(searchingPlan, 5, 1);
		for (PlanBean plan : planList) {
			System.out.println(plan.toString());
			System.out.println(plan.getPlanContent().replace("\n", "<br>"));
		}*/

//------------------------------------------------------------追加テスト---------------------------------------------------
/*		PlanBean plan = new PlanBean();
		plan.setPlanName("【プレミアムフライデー限定】二泊三日の週末満喫プラン");
		plan.setPlanContent("特別な金曜日にお勧め！　夕食・朝食つきの5部屋限定プラン！");
		plan.setCategoryCode(2);
		plan.setInnId(2);
		plan.setPrice(23900);
		plan.setRoomQuantity(5);

		planDao.addPlan(plan);*/

		//------------------------------------------------------ ID検索テスト------------------------------------------------------
//		System.out.println(planDao.getPlan(1));

		//------------------------------------------------------ 更新テスト------------------------------------------------------
/*		PlanBean updatePlan = new PlanBean();
		updatePlan.setCategoryCode(2);
		updatePlan.setInnId(1);
		updatePlan.setPlanContent("更新しました！！！");
		updatePlan.setPlanId(56);
		System.out.println(planDao.updatePlan(updatePlan));*/
	}
}