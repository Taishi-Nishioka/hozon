import java.time.LocalDate;

import bean.ReservationBean;
import dao.ReservationDao;

public class TestReservation {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ


		ReservationBean reservation = new ReservationBean();

		reservation.setMemberId(1);
		reservation.setPlanId(1);
		reservation.setReservationId(1);
		reservation.setCheckinDate(java.sql.Date.valueOf(LocalDate.parse("2021-07-07")));
		reservation.setCheckoutDate(java.sql.Date.valueOf(LocalDate.parse("2021-07-09")));
		reservation.setRoomQuantity(1);

        ReservationDao DAO = new ReservationDao();
		//DAO.reservation(reservation).toString();

//		System.out.println(DAO.reservation(reservation).toString());

	}

}
