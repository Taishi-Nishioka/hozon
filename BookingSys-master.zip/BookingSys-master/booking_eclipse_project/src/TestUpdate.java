import java.sql.Date;

import bean.MemberBean;
import dao.MemberDao;

public class TestUpdate {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
			// TODO 自動生成されたメソッド・スタブ
			MemberDao dao = new MemberDao();

			MemberBean bean = new MemberBean();
			bean.setMemberID(4);
			bean.setMemberName("麻生太郎");
			bean.setMemberPostalCode(6666666);
			bean.setMemberAddress("東京都hogehoge");
			bean.setPhoneNum("0120-222-2222");
			bean.setEmail("taroaso@ezweb.ne.jp");
			bean.setBirthday(new Date(2021,12,31));
			bean.setPassword("aaabbccc");
			dao.updateMember(bean);
	}

}
