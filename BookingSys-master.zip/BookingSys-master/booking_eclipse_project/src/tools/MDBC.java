package tools;

import java.sql.Connection;
import java.sql.DriverManager;

import exception.DAOException;

public class MDBC {
	//Connectionの確立
	public static Connection getConnection() throws DAOException {
		try {
			Connection con;
			// JDBCドライバ
			Class.forName("org.postgresql.Driver");
			String url = "jdbc:postgresql://hotereach.com/booking?useUnicode=true&characterEncoding=utf8";
			String user = "hotereach";
			String pass = "hrhimitu";
			con = DriverManager.getConnection(url, user, pass);
			return con;
		} catch (Exception e) {
			throw new DAOException("接続に失敗しました");
		}
	}
	
	public static Connection getLocalConnection() throws DAOException {
		try {
			Connection con;
			// JDBCドライバ
			Class.forName("org.postgresql.Driver");
			String url = "jdbc:postgresql:sample?useUnicode=true&characterEncoding=utf8";
			String user = "student";
			String pass = "himitu";
			con = DriverManager.getConnection(url, user, pass);
			return con;
		} catch (Exception e) {
			throw new DAOException("接続に失敗しました");
		}
	}
}
