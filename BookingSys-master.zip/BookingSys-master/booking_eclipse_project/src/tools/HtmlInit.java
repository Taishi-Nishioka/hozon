package tools;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HtmlInit {
	private final String HTML_HEAD1 = "<html>\n<head>\n<title>";
	private final String CSS_LINK = "";//"<link rel=\"stylesheet\" href=\"css/style.css\" type=\"text/css\">";
	private final String HTML_HEAD2 = "</title>\n" + CSS_LINK + "</head>\n<body>";
	private final String HTML_FOOT = "\n</body></html>";

	private String article = "";
	private String title = "default title";

	HtmlInit(){
		article = "";
	}

	HtmlInit(String str){
		article = str;
	}

	public static void setContentUtf8(HttpServletRequest request, HttpServletResponse response) {
		response.setContentType("text/html;charset=UTF-8");
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}

	public void addArticleH1(String str) {
		article = article + "<h1>" + str + "</h1>\n";
	}

	public void addArticleH2(String str) {
		article = article + "<h2>" + str + "</h2>\n";
	}

	public void addArticleH3(String str) {
		article = article + "<h3>" + str + "</h3>\n";
	}

	public void addArticle(String str) {
		article = article + str;
	}

	public void addArticleP(String str) {
		article = article + "<p>" + str + "</p>\n";
	}

	public void addArticleP(String element,String id) {
		article = article + String.format("<p id='%s'>%s</p>\n", element, id);
	}

	public void addArticleP(String element,String id,String htClass) {
		article = article + String.format("<p id='%s' class='%s'>%s</p>\n", element, id, htClass);
	}

	public void addArticleE(String e,String str) {
		article = article + String.format("<%s>%s</%s>", e, str, e);
	}

	public void addArticleE(String e,String str, String id) {
		article = article + String.format("<%s id='%s'>%s</%s>\n", e, id, str, e);
	}

	public void addArticleE(String e, String str,String id,String htClass) {
		article = article + String.format("<%s id='%s' class='%s'>%s</%s>\n", e, id, htClass, str, e);
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getArticle() {
		return article;
	}

	@Override public String toString() {
		return HTML_HEAD1 + title + HTML_HEAD2 + article + HTML_FOOT;
	}
}
