package tools;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletTools {
	public static void errorMessage(String message, HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("message", message);
		viewPage("error.jsp", request, response);
	}

	public static void viewPage(String address, HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher(address);
		rd.forward(request, response);
	}

	public static boolean equalString(String str1, String str2) {
		if (str1 == null) {
			return false;
		} else if (str1.equals(str2)) {
			return true;
		} else {
			return false;
		}
	}
}
