- Inn //横山
    - 宿検索(宿と住所のアレ・プラン前のやつ)
    searchInnNA(inn_name,inn_address) :InnBean
        searchInnName(String sql,String inn_name)  //宿名を引っ張てくる
        searchInnAddress(Sring sql,String inn_address) //住所を引っ張てくる

    - 宿検索
    searchInn(inn_name,inn_addressNo,inn_address)  : List<InnBean>
        searchInnName(String sql,String inn_name) :String //宿名を引っ張てくる
        searchInnAddressNo(Sring sql,String inn_address) :String //郵便番号を引っ張てくる。
        searchInnAddress(Sring sql,String inn_address) :String //住所を引っ張てくる。部分一致
        

        - 宿名 inn_name = ?
        - 分類コード cateegory_code = ?
        - 住所 address = ?
        - チェックイン時間 checkin =< ?
        - チェックアウト時間 checkout => ?

    - 宿追加 : InnBean//宿名,郵便番号,住所,分類コード,チェックイン時間,チェックアウト時間

    addInn()
    - searchInnName()
    - searchInnAddress()

    - setInnName()
    - setcatCode()
    - setaddress()
    - setCheckinTime()
    - setCheckoutTime()
    
    - 宿削除 : InnBean
    deleteInn()
    - searchId()
    - setDeleteInn()
