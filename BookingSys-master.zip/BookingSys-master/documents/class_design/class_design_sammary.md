# Bean
- RseservationBean (予約テーブル用Bean)
- StayingPlanBean (宿泊プラン用Bean)
- InnBean (宿リスト用Bean)
- MemberBean (会員用Bean)

# DAO
- ReservationDao
- StayingPlanDao
- InnDao
- MemberDao
- CategoryDao -> MapTree<int, String>

# Functions
- Reservation //須田
    - addReservation(int, DATE, DATE, int) 宿泊プラン, チェックイン, チェックアウト, 部屋数: int(予約IDを返す)
    - removeReservation : boolean
    - 予約検索
    - 予約変更
    - searchVacancy : int(空き部屋検索)

- StayingPlan //前中
    - addStayingPlan() : void
    - removeStayingPlan(int) : boolean
    - searchStayingPlan(String, String, boolean) - 宿名検索 : ArrayList<StayingPlanBean>
    - searchStayingPlan(String, String, String, boolean) - 宿名,プラン内容検索 : ArrayList<StayingPlanBean>
    - searchStayingPlan(String, String, int, int, String, boolean) - 宿名,プラン内容,値段検索 : ArrayList<StayingPlanBean>
    - searchStayingPlan(int, int, String, boolean) - 値段検索 : ArrayList<StayingPlanBean>
    - getStayingPlan(int) - ID検索 : StayingPlanBean

- Inn //横山

searchInn{
    Stirng sql = "SELECT * FROM inn_index WHERE"
    sql = sql + searchAddName()[" name = ?"]
    println(sql) -> "SELECT * FROM inn_index WHERE name = ?"
    sql = sql + searchAddCategory_code()["AND category_code = ?"]
    println(sql) -> "SELECT * FROM inn_index WHERE name = ? AND category_code = ?"
}

searchAdd(sql,String name){
    if ( sql.substring(sql.size() - 6, sql.length() - 1) == "WHERE"){ //sqlの右側5文字がWHEREだったら
        return " name = '大川荘'";
    }else{
        return " AND name = '大川荘'";
    }
}

searchByAddressName(String, String){}
searchByName(String){}
searchByAddress(Strging){}

    - 宿名 inn_name = ?
    - 分類コード cateegory_code = ?
    - 住所 address = ?
    - チェックイン時間 checkin =< ?
    - チェックアウト時間 checkout => ?

    - 宿検索 : List<InnBean>
    - 宿追加 : InnBean
    - 宿削除 : InnBean

- Member //遠藤
    - addMember : MemberBean(失敗時はnull)
    - searchMember : List<MemberBean>
    - updateMember : MemberBean
    - cancelMemberchip : boolean
    - Role(権限変更) : boolean