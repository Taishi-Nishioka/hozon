- Member //遠藤
    - addMember : MemberBean(失敗時はnull)
    //String sql = "SELECT * FROM member WHERE ?";
    - searchID(int memberID ) : MemberBean //会員IDで検索(完全一致)
    sql = sql +   ;
    - searchMember : List<MemberBean>
        
        - searchAddName(String sql, String memberName)   //氏名で検索
        
        - searchAddPhoneNum(String sql, String phoneNum)   //電話番号で検索

        - searchAddEmail(String email, String sql)    //Emailで検索
        "SELECET email FROM member WHERE"
        
        - searchAddBirthday(String sql, DATE) //生年月日で検索



    - updateMember : MemberBean
    - cancelMemberchip : boolean
    - Role(権限変更) : boolean