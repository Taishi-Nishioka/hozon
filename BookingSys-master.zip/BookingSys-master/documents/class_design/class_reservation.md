- Reservation //須田
    - 予約追加 : bean
     - addReservation(int, DATE, DATE, int) 宿泊プラン, チェックイン, チェックアウト, 部屋数: int(予約IDを返す)

   　　　　　
    - 予約数検索 : List
      - serchReservation (int 会員ID): int(予約数を返す)
      会員IDとキャンセルがfalseと未来のチェックイン日

    　　　
    - 空室検索 : List
      - searchVacancy (int, DATE, DATE) 宿泊プラン, チェックイン, チェックアウト : int(部屋数を返す)