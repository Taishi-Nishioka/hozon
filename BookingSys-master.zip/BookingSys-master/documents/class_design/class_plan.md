- StayingPlan //前中
    - addStayingPlan() : StayingPlanBean
    - removeStayingPlan(int) : boolean
    - searchStayingPlan() : ArrayList<StayingPlanBean> //検索文の実行メソッド

      String sql = "SELECT inn_name, cat_name, plan_contents, price, inn_address FROM staying_plan NATURAL JOIN inn_index NATURAL JOIN category WHERE"
    
      - searchAddId(String sql, int id) : String // SQLの末尾にID検索を入れる。
      - searchAddName(String sql, String Name) : String // SQLの末尾にプラン名検索を入れる。
      - searchAddPrice(String sql, int lowPrice, int highPrice) : String // SQLの末尾に金額検索を入れる。
      - searchAddInnName(String sql, String InnName) : String // SQLの末尾に宿名検索を入れる。
      - searchByAdmin(boolean) : String //管理者による検索かどうかを判断する。

    - getStayingPlan(int) - ID検索 : StayingPlanBean