1. Beanの実装
2. Daoの実装
3. javaファイル(mainメソッドを用いてのテスト)
4. jspおよびServletの実装
    1. jspの実装
    2. 表示のテスト
    3. Servletへデータが送られていることの確認
    4. Servletのフォワード前までの実装
    5. JSPでフォワーディングを受け取って値の表示

## サーブレット実装時
```java
session.setAttribute("loginMenber",
                    loginMember);

HttpSession session;
int i;
int j;
int k;
session = request.getSession();
MemberBean loginMember = (MemberBean)session.getAttribute("loginMember"); // MemberBean
if (loginMember != null){
    //ログインされている
}else{
    //ログインされていない
}
```